# GitHub Stars MCP

MCP (Model Context Protocol) server for growing your GitHub repo. Gives your AI assistant (Claude, Cline, etc.) superpowers to analyze, compare, and optimize open-source projects.

## ✅ What it does

**Free features (GitHub API, no login needed):**
- 🔍 `analyze_repo` — deep analysis: stars, forks, growth rate, contributors, languages
- 📊 `compare_repos` — compare multiple repos by stars/forks/activity
- 🔎 `find_similar_repos` — discover repos in your niche, learn from what they do well
- 📈 `track_star_growth` — track star growth over time

**Premium features (GitHub Sponsors):**
- 🤖 `optimize_readme` — AI-powered README rewrite (uses DeepSeek API)
- 🎯 Personalized growth recommendations
- 📋 Competitor analysis report

## 🚀 Quick Start

```bash
npm install
npm start
```

Add to your MCP client (Claude Desktop / Cline / etc.):

```json
{
  "mcpServers": {
    "github-stars": {
      "command": "node",
      "args": ["/path/to/github-stars-mcp/index.js"],
      "env": {
        "GITHUB_TOKEN": "your-github-token-here"
      }
    }
  }
}
```

**Get a free GitHub token** (increases rate limit):
1. Go to https://github.com/settings/tokens
2. Generate a new token (no special scopes needed for public repos)
3. Add it to `.env` or the MCP config

## 🔑 Getting a GitHub Token (free)

1. Go to https://github.com/settings/tokens
2. Click **Generate new token (classic)**
3. No scopes needed for public repo data
4. Copy the `ghp_xxx` token
5. Add to `.env`:
   ```
   GITHUB_TOKEN=ghp_xxxxxxxxxx
   ```

Free rate limit: **60 requests/hour** (with token: **5000 requests/hour**)

## 🔑 Premium Features

1. Go to: https://github.com/sponsors/1036007003-wq
2. Pick a tier ($5 / $10 / $25 per month)
3. You'll receive a `LICENSE_KEY`
4. Add it to your `.env` file:
   ```
   LICENSE_KEY=your-license-key
   ```
5. (Optional) Add DeepSeek API key for AI README optimization:
   ```
   DEEPSEEK_API_KEY=sk-xxx
   ```

## 📖 Example Usage (in Claude / Cline)

```
Analyze my repo: 1036007003-wq/reddit-marketing-mcp
```

```
Compare these repos: facebook/react, vuejs/vue, anglar/anglar
```

```
Find repos similar to my MCP project.
```

```
[Premium] Optimize the README for my repo: 1036007003-wq/twitter-marketing-mcp
```

## 🛠️ Tech Stack

- `@modelcontextprotocol/sdk` — MCP protocol
- `node-fetch` — HTTP requests
- GitHub REST API v3 (free, no auth needed for public repos)
- DeepSeek API (optional, for AI README optimization)

## 🤝 Contributing

PRs welcome! Especially:
- More GitHub API endpoints
- Better AI optimization prompts
- Support for GitHub GraphQL API
- More growth recommendations

## 📄 License

MIT — free to use, modify, and distribute.

## ⭐ Support

If this tool helps you grow your repo, please:
- ⭐ Star this repo
- ☕ [Sponsor on GitHub](https://github.com/sponsors/1036007003-wq)
- 🐛 [Report issues](https://github.com/1036007003-wq/github-stars-mcp/issues)

---

**Made with ❤️ by [wangchenji](https://github.com/1036007003-wq)**
