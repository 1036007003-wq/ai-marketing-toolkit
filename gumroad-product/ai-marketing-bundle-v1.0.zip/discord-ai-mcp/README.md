# Discord AI Marketing MCP v1.0.0

**Free MCP server to grow Discord communities — find servers, draft messages, analyze engagement. Premium features powered by DeepSeek AI.**

[![npm version](https://badge.fury.io/js/discord-ai-mcp.svg)](https://www.npmjs.com/package/discord-ai-mcp)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Sponsor](https://img.shields.io/badge/Sponsor-💖-pink.svg)](https://github.com/sponsors/1036007003-wq)

---

## 🚀 Quick Start (FREE, no API key needed)

```bash
# Install
npm install -g discord-ai-mcp

# Add to your MCP client (e.g., Cline, Claude Desktop)
# No API key needed for FREE features!
node /path/to/discord-ai-mcp/index.js
```

**That's it!** Start using these FREE tools immediately:
- `search_public_servers` — Find Discord servers by keyword
- `analyze_server_engagement` — Check if a server is active (via invite link)
- `draft_community_message` — Template-based message drafts

---

## 🔧 FREE Features (no API key)

| Tool | What it does | No API key? |
|------|---------------|--------------|
| `search_public_servers` | Search Disboard.org for public servers | ✅ Works immediately |
| `analyze_server_engagement` | Check server activity via invite link | ✅ Works immediately |
| `draft_community_message` | Draft a community intro/pitch (template) | ✅ Works immediately |

---

## 💎 PREMIUM Features (requires DeepSeek API key)

Set `DEEPSEEK_API_KEY` in your `.env` file to unlock:

| Tool | What it does | Why it's worth paying for |
|------|---------------|----------------------------|
| `find_relevant_channels` | AI suggests the best channels to post in | Saves hours of manual searching |
| `draft_community_message` (AI mode) | AI-personalized drafts matching community tone | 10x better than templates |
| `generate_moderation_rules` | AI-generated community rules | Save time setting up your own server |

**Get a DeepSeek API key:** https://platform.deepseek.com (cheap, ~$0.14/1M tokens)

---

## 📦 Installation

### For MCP Client Users (Claude Desktop, Cline, etc.)

Add to your MCP client config:

```json
{
  "mcpServers": {
    "discord-ai-marketing": {
      "command": "node",
      "args": ["/path/to/discord-ai-mcp/index.js"],
      "env": {
        "DEEPSEEK_API_KEY": "sk-xxx" // Optional, for premium features
      }
    }
  }
}
```

### For Developers

```bash
git clone https://github.com/1036007003-wq/discord-ai-mcp.git
cd discord-ai-mcp
npm install
node index.js
```

---

## 🎯 Use Cases

### 1. Find the right Discord servers to promote in
```
Use `search_public_servers` with keyword "AI"
→ Returns top Discord servers for AI communities
```

### 2. Check if a server is worth joining
```
Use `analyze_server_engagement` with invite link
→ Returns: Member count, online ratio, activity level
```

### 3. Draft a non-salesy intro post
```
Use `draft_community_message`
→ Returns: Template-based message (or AI draft with DeepSeek)
```

### 4. (Premium) Find the best channels to post in
```
Use `find_relevant_channels` with server description
→ Returns: AI-suggested channels (e.g., #showcase, #projects)
```

---

## 🌏 For China Users (中国用户)

```bash
# If you can't access Discord API directly:
# 1. Set proxy
export HTTP_PROXY=http://127.0.0.1:7890
export HTTPS_PROXY=http://127.0.0.1:7890

# 2. Or use a China-friendly API proxy
# (We recommend setting up your own proxy, or use a VPN)
```

---

## 🏆 Why This is Better Than...

| Alternative | Problem | Our Solution |
|-------------|-----------|--------------|
| Manual Discord research | Takes hours, boring | Automated in seconds |
| Buying Discord ads | Expensive ($100+ / mo) | Free basic features |
| Hiring a community manager | $500+ / month | One-time setup |
| Other Discord bots | Require Bot token (complicated) | No token needed for basic features |

---

## 📊 Roadmap

- [x] Free: Search public servers
- [x] Free: Analyze server engagement
- [x] Free: Draft community messages (template)
- [x] Premium: AI-powered message drafting (DeepSeek)
- [x] Premium: Find relevant channels (AI)
- [x] Premium: Generate moderation rules (AI)
- [ ] Paid: Auto-moderation bot template
- [ ] Paid: Invite tracking dashboard
- [ ] Paid: Sentiment analysis for community feedback

---

## 💰 Pricing (GitHub Sponsors)

| Tier | Price | What you get |
|------|-------|---------------|
| **Free** | $0 | 3 basic tools (no API key needed) |
| **Supporter** | $5/mo | All premium features + priority support |
| **Team** | $25/mo | All premium + custom AI prompts + Discord bot template |
| **One-time** | $99 | Lifetime access (no subscription) |

👉 **Sponsor here:** https://github.com/sponsors/1036007003-wq

---

## 🐛 Issues / Feature Requests

Open an issue: https://github.com/1036007003-wq/discord-ai-mcp/issues

---

## ⭐ Star History

[![Star History Chart](https://api.star-history.com/svg?repos=1036007003-wq/discord-ai-mcp&type=Date)](https://star-history.com/#1036007003-wq/discord-ai-mcp&Date)

---

**Built by [@1036007003-wq](https://github.com/1036007003-wq) | Sponsor on GitHub ❤️**
