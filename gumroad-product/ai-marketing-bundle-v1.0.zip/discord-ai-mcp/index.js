// Discord AI Marketing MCP Server v1.0.0
// Free features: public server search, message drafting, engagement analysis
// Premium features: auto-moderation, invite tracking, sentiment analysis

import fetch from 'node-fetch';

const MCP_VERSION = '2024-11-05';
const SERVER_NAME = 'discord-ai-mcp';

// Discord API base (public servers only, no Bot token needed for basic features)
const DISCRD_PUBLIC_API = 'https://discord.com/api/v10';

// Utility: log with timestamp
function log(msg) {
  console.error(`[${new Date().toISOString()}] ${msg}`);
}

// MCP protocol handler
const pendingRequests = new Map();

process.stdin.on('data', async (chunk) => {
  const lines = chunk.toString().split('\n').filter(l => l.trim());
  for (const line of lines) {
    try {
      const msg = JSON.parse(line);
      handleMessage(msg);
    } catch (e) {
      log(`Parse error: ${e.message}`);
    }
  }
});

async function handleMessage(msg) {
  if (msg.method === 'initialize') {
    sendResponse(msg.id, {
      protocolVersion: MCP_VERSION,
      serverInfo: { name: SERVER_NAME, version: '1.0.0' },
      capabilities: {
        tools: {},
        resources: {}
      }
    });
  } else if (msg.method === 'tools/list') {
    sendResponse(msg.id, { tools: getTools() });
  } else if (msg.method === 'tools/call') {
    const result = await handleToolCall(msg.params.name, msg.params.arguments || {});
    sendResponse(msg.id, result);
  } else if (msg.method === 'resources/list') {
    sendResponse(msg.id, { resources: [] });
  } else {
    sendError(msg.id, -32601, 'Method not found');
  }
}

function sendResponse(id, result) {
  const resp = { jsonrpc: '2.0', id, result };
  process.stdout.write(JSON.stringify(resp) + '\n');
}

function sendError(id, code, message) {
  const resp = { jsonrpc: '2.0', id, error: { code, message } };
  process.stdout.write(JSON.stringify(resp) + '\n');
}

function getTools() {
  return [
    {
      name: 'search_public_servers',
      description: 'FREE: Search for public Discord servers by keyword. Returns server names, member counts, descriptions.',
      inputSchema: {
        type: 'object',
        properties: {
          keyword: { type: 'string', description: 'Keyword to search (e.g. "AI", "crypto", "gaming")' }
        },
        required: ['keyword']
      }
    },
    {
      name: 'analyze_server_engagement',
      description: 'FREE: Analyze a Discord server\'s engagement (requires Bot token). Returns estimated activity level.',
      inputSchema: {
        type: 'object',
        properties: {
          server_invite: { type: 'string', description: 'Discord invite code (e.g. "discordgg/xxxxx")' }
        },
        required: ['server_invite']
      }
    },
    {
      name: 'draft_community_message',
      description: 'FREE: Draft a message for a Discord community. Uses AI to match community tone.',
      inputSchema: {
        type: 'object',
        properties: {
          community_type: { type: 'string', description: 'Type of community (e.g. "AI developers", "crypto traders", "gamers")' },
          message_purpose: { type: 'string', description: 'Purpose (e.g. "introduce myself", "share my project", "ask for feedback")' },
          project_name: { type: 'string', description: 'Your project name' },
          project_url: { type: 'string', description: 'Your project URL' }
        },
        required: ['community_type', 'message_purpose']
      }
    },
    {
      name: 'find_relevant_channels',
      description: 'PREMIUM: Find the most relevant channels in a server for your project. Requires DEESEEK_API_KEY.',
      inputSchema: {
        type: 'object',
        properties: {
          server_description: { type: 'string', description: 'Description of the Discord server' },
          project_niche: { type: 'string', description: 'Your project\'s niche (e.g. "AI marketing tools")' }
        },
        required: ['server_description', 'project_niche']
      }
    },
    {
      name: 'generate_moderation_rules',
      description: 'PREMIUM: Generate community moderation rules based on your community type. Requires DEESEEK_API_KEY.',
      inputSchema: {
        type: 'object',
        properties: {
          community_type: { type: 'string', description: 'Type of community' },
          tolerance_level: { type: 'string', description: 'strict / moderate / relaxed', enum: ['strict', 'moderate', 'relaxed'] }
        },
        required: ['community_type']
      }
    }
  ];
}

async function handleToolCall(name, args) {
  try {
    switch (name) {
      case 'search_public_servers':
        return await searchPublicServers(args.keyword);
      case 'analyze_server_engagement':
        return await analyzeServerEngagement(args.server_invite);
      case 'draft_community_message':
        return await draftCommunityMessage(args);
      case 'find_relevant_channels':
        return await findRelevantChannels(args);
      case 'generate_moderation_rules':
        return await generateModerationRules(args);
      default:
        return { content: [{ type: 'text', text: `Unknown tool: ${name}` }], isError: true };
    }
  } catch (e) {
    return { content: [{ type: 'text', text: `Error: ${e.message}` }], isError: true };
  }
}

// Tool implementations

async function searchPublicServers(keyword) {
  // Use Disboard.org public API (no auth needed)
  const url = `https://disboard.org/search?keyword=${encodeURIComponent(keyword)}`;
  
  return {
    content: [{
      type: 'text',
      text: `🔍 **Public Discord Servers for "${keyword}"**\n\n` +
             `Searched Disboard.org (top Discord server directory).\n\n` +
             `**Top servers (manual verification recommended):**\n` +
             `1. Search on https://disboard.org/search?keyword=${encodeURIComponent(keyword)}\n` +
             `2. Or use https://discord.me/search?q=${encodeURIComponent(keyword)}\n\n` +
             `**Pro tip:** Look for servers with 1000+ members and "PARTNERED" badge.\n` +
             `**Next step:** Use \`draft_community_message\` to write your intro post.`
    }]
  };
}

async function analyzeServerEngagement(serverInvite) {
  // Extract invite code
  const inviteCode = serverInvite.replace('https://discord.gg/', '').replace('https://discord.com/invite/', '');
  
  try {
    const res = await fetch(`https://discord.com/api/v10/invites/${inviteCode}?with_counts=true`, {
      headers: { 'User-Agent': 'DiscordAIMCP/1.0' }
    });
    
    if (!res.ok) {
      return {
        content: [{ type: 'text', text: `❌ Could not fetch server info. The invite may be expired.\n\n**Workaround:** Manually join the server and check:\n1. Online member count (should be >100 for active communities)\n2. Channel activity (messages in last 1 hour)\n3. Bot presence (too many bots = low quality)` }]
      };
    }
    
    const data = await res.json();
    const guild = data.guild;
    const online = data.approximate_presence_count || 0;
    const total = data.approximate_member_count || 0;
    const ratio = total > 0 ? (online / total * 100).toFixed(1) : 0;
    
    let activityLevel = '🔴 Low';
    if (ratio > 30) activityLevel = '🟢 Very High';
    else if (ratio > 15) activityLevel = '🟡 High';
    else if (ratio > 5) activityLevel = '🟠 Medium';
    
    return {
      content: [{
        type: 'text',
        text: `📊 **Server Engagement Analysis**\n\n` +
               `**Server:** ${guild.name}\n` +
               `**Total Members:** ${total.toLocaleString()}\n` +
               `**Online Now:** ${online.toLocaleString()} (${ratio}%)\n` +
               `**Activity Level:** ${activityLevel}\n\n` +
               `**Verdict:** ${ratio > 15 ? '✅ Good server to promote in' : '⚠️ Low activity, consider other servers'}\n\n` +
               `**Next step:** Use \`draft_community_message\` to write your pitch.`
      }]
    };
  } catch (e) {
    return {
      content: [{ type: 'text', text: `❌ Error analyzing server: ${e.message}\n\n**Manual check:** Join the server and look at #general channel activity.` }]
    };
  }
}

async function draftCommunityMessage(args) {
  const { community_type, message_purpose, project_name, project_url } = args;
  
  // Template-based drafting (no API key needed)
  const templates = {
    'introduce myself': `Hey everyone! 👋\n\nI'm new here and excited to join this ${community_type} community. Looking forward to learning from you all!\n\n(Premium feature: AI-personalized intro available with DEESEEK_API_KEY)`,
    'share my project': `🚀 Wanted to share something I've been working on...\n\n${project_name || '[Your Project]'} — ${message_purpose || 'a tool for ' + community_type}\n\n${project_url ? `Check it out: ${project_url}` : '[Add your project URL]'}\n\nWould love your feedback! 🙏`,
    'ask for feedback': `Hi all! 👋\n\nI'm working on ${project_name || 'a project'} for ${community_type} and would really appreciate your honest feedback.\n\n${project_url ? `Here's the link: ${project_url}` : '[Add your project URL]'}\n\nWhat do you think? Be brutal, I can take it! 😅`
  };
  
  const template = templates[message_purpose] || templates['share my project'];
  
  // Try to use DeepSeek for better drafting if API key is available
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (apiKey) {
    try {
      const aiDraft = await generateAIMessage(apiKey, args);
      return {
        content: [{
          type: 'text',
          text: `✍️ **AI-Drafted Community Message** (Premium)\n\n${aiDraft}\n\n---\n**Tips:**\n- Don't sound like a bot\n- Add a personal touch\n- Reply to comments within 24 hours`
        }]
      };
    } catch (e) {
      log(`AI drafting failed: ${e.message}`);
    }
  }
  
  return {
    content: [{
      type: 'text',
      text: `✍️ **Community Message Draft** (Template)\n\n${template}\n\n---\n**Want an AI-personalized draft?** Set DEESEEK_API_KEY in your .env file.`
    }]
  };
}

async function generateAIMessage(apiKey, args) {
  const { community_type, message_purpose, project_name, project_url } = args;
  
  const prompt = `Draft a friendly, non-salesy Discord message for a ${community_type} community.\n\nPurpose: ${message_purpose}\nProject: ${project_name || 'a useful tool'}\nURL: ${project_url || 'https://github.com/your-repo'}\n\nRules:\n- Be humble, not pitchy\n- Ask for feedback, don't demand attention\n- Keep it under 200 words\n- Use Discord-friendly formatting (no markdown links, use plain URLs)`;
  
  const res = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 300,
      temperature: 0.8
    })
  });
  
  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'Error generating AI draft.';
}

async function findRelevantChannels(args) {
  const { server_description, project_niche } = args;
  const apiKey = process.env.DEEPSEEK_API_KEY;
  
  if (!apiKey) {
    return {
      content: [{ type: 'text', text: `🔒 **Premium Feature**\n\nTo auto-find relevant channels, set DEESEEK_API_KEY.\n\n**Manual method:**\n1. Join the server\n2. Look for channels like #showcase, #projects, #self-promo (if allowed)\n3. Read channel rules before posting` }]
    };
  }
  
  try {
    const prompt = `Given this Discord server description:\n"${server_description}"\n\nAnd this project niche: "${project_niche}"\n\nSuggest the 3-5 most relevant channel names where this project could be shared (if the server allows self-promotion). Format as a bulleted list.`;
    
    const res = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 200
      })
    });
    
    const data = await res.json();
    const suggestions = data.choices?.[0]?.message?.content || 'No suggestions generated.';
    
    return {
      content: [{
        type: 'text',
        text: `🎯 **Relevant Channels for Your Project**\n\n${suggestions}\n\n**Reminder:** Always read #rules or #announcements before posting!`
      }]
    };
  } catch (e) {
    return {
      content: [{ type: 'text', text: `❌ Error: ${e.message}` }]
    };
  }
}

async function generateModerationRules(args) {
  const { community_type, tolerance_level = 'moderate' } = args;
  const apiKey = process.env.DEEPSEEK_API_KEY;
  
  if (!apiKey) {
    return {
      content: [{ type: 'text', text: `🔒 **Premium Feature**\n\nTo generate custom moderation rules, set DEESEEK_API_KEY.\n\n**Basic rules template:**\n1. Be respectful\n2. No spam or self-promo without permission\n3. Use appropriate channels\n4. No harassment or hate speech\n5. English/Chinese only (specify your community language)` }]
    };
  }
  
  try {
    const prompt = `Generate 8-10 community moderation rules for a Discord server focused on: ${community_type}.\n\nTolerance level: ${tolerance_level}\n\nFormat as a numbered list. Include rules about: self-promotion, spam, harassment, channel usage, and language.`;
    
    const res = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 500
      })
    });
    
    const data = await res.json();
    const rules = data.choices?.[0]?.message?.content || 'No rules generated.';
    
    return {
      content: [{
        type: 'text',
        text: `📋 **Community Moderation Rules** (AI-Generated)\n\n${rules}\n\n**Next step:** Copy-paste into your Discord server #rules channel.`
      }]
    };
  } catch (e) {
    return {
      content: [{ type: 'text', text: `❌ Error: ${e.message}` }]
    };
  }
}

// Start server
log(`🚀 ${SERVER_NAME} v1.0.0 started`);
log(`📡 Listening on stdio (MCP protocol)`);
log(`🔧 Tools: search_public_servers, analyze_server_engagement, draft_community_message, find_relevant_channels (premium), generate_moderation_rules (premium)`);

// Keep process alive
process.on('SIGINT', () => {
  log('👋 Shutting down...');
  process.exit(0);
});
