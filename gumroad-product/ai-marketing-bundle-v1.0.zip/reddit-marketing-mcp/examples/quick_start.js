#!/usr/bin/env node
/**
 * Reddit Marketing MCP - Quick Start Example
 * Run: node examples/quick_start.js
 */

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const root = join(__dirname, '..');

// Start MCP server
const server = spawn('node', ['index.js'], {
  cwd: root,
  stdio: ['pipe', 'pipe', 'pipe']
});

// MCP protocol helper
function sendRequest(id, method, params = {}) {
  const req = {
    jsonrpc: '2.0',
    id,
    method,
    params
  };
  server.stdin.write(JSON.stringify(req) + '\n');
}

// Parse responses
let buffer = '';
server.stdout.on('data', (data) => {
  buffer += data.toString();
  const lines = buffer.split('\n');
  buffer = lines.pop(); // Keep incomplete line in buffer
  
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const resp = JSON.parse(line);
      console.log('\n✅ Response:', JSON.stringify(resp.result || resp.error, null, 2));
    } catch (e) {
      console.log('📝 Log:', line);
    }
  }
});

server.stderr.on('data', (data) => {
  console.error('🔧 Server:', data.toString().trim());
});

// Demo workflow
setTimeout(() => {
  console.log('🔍 Researching r/javascript...');
  sendRequest(1, 'tools/call', {
    name: 'research_subreddit',
    arguments: { subreddit: 'javascript' }
  });
}, 1000);

setTimeout(() => {
  console.log('\n🔥 Finding trending posts in r/SideProject...');
  sendRequest(2, 'tools/call', {
    name: 'find_trending_posts',
    arguments: { subreddit: 'SideProject', limit: 3 }
  });
}, 3000);

setTimeout(() => {
  console.log('\n📊 Analyzing competitor u/spez...');
  sendRequest(3, 'tools/call', {
    name: 'analyze_competitor',
    arguments: { username: 'spez' }
  });
}, 5000);

setTimeout(() => {
  console.log('\n✍️  Generating a post about AI tools...');
  sendRequest(4, 'tools/call', {
    name: 'generate_post',
    arguments: {
      topic: 'I built 3 AI tools to automate Reddit marketing',
      tone: 'casual'
    }
  });
}, 7000);

setTimeout(() => {
  console.log('\n✅ Demo complete! Check the responses above.');
  server.kill();
  process.exit(0);
}, 10000);
