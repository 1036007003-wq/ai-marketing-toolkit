# Reddit Marketing MCP

MCP (Model Context Protocol) server for Reddit marketing automation. Gives your AI assistant (Claude, Cline, etc.) real-time Reddit superpowers.

## ✅ What it does

**Free features (no login needed):**
- 🔍 `research_subreddit` — deep analysis: subscriber count, growth, best posting times, what content works
- 🔥 `find_trending_posts` — spot hot posts before they peak
- 🕵️ `analyze_competitor` — track what your competitors are doing on Reddit

**Premium features (GitHub Sponsors):**
- 🤖 `generate_post` — AI post generation that matches subreddit tone (uses DeepSeek API)
- ⏰ `schedule_post` — auto-schedule for optimal engagement
- 📊 `track_metrics` — marketing KPI dashboard

## 🚀 Quick Start

```bash
npm install
npm start
```

Add to your MCP client (Claude Desktop / Cline / etc.):

```json
{
  "mcpServers": {
    "reddit-marketing": {
      "command": "node",
      "args": ["/path/to/reddit-marketing-mcp/index.js"],
      "env": {}
    }
  }
}
```

## 🌏 China Users (Reddit is blocked)

Set a proxy in `.env`:

```
HTTP_PROXY=http://127.0.0.1:7890
HTTPS_PROXY=http://127.0.0.1:7890
```

Or use a VPN before running the server.

## 🔑 Premium Features

1. Go to: https://github.com/sponsors/1036007003-wq
2. Pick a tier ($5 / $10 / $25 per month)
3. You'll receive a `LICENSE_KEY`
4. Add it to your `.env` file:
   ```
   LICENSE_KEY=your-license-key
   ```
5. (Optional) Add DeepSeek API key for AI post generation:
   ```
   DEEPSEEK_API_KEY=sk-xxx
   ```

## 📖 Example Usage (in Claude / Cline)

```
Research r/SideProject for me — what's the best time to post?
```

```
Find trending posts on Reddit in the last 24 hours.
```

```
Analyze my competitor u/theirusername — what's their top post?
```

```
[Premium] Generate a Reddit post for r/SaaS about my SaaS tool.
```

## 🛠️ Tech Stack

- `@modelcontextprotocol/sdk` — MCP protocol
- `node-fetch` — HTTP requests
- Reddit Public JSON API (no auth needed for reading)
- DeepSeek API (optional, for AI post generation)

## 🤝 Contributing

PRs welcome! Especially:
- More Reddit API endpoints
- Better AI post generation prompts
- Support for more LLM providers (OpenAI, Claude, etc.)

## 📄 License

MIT — free to use, modify, and distribute.

## ⭐ Support

If this tool helps you get more out of Reddit, please:
- ⭐ Star this repo
- ☕ [Sponsor on GitHub](https://github.com/sponsors/1036007003-wq)
- 🐛 [Report issues](https://github.com/1036007003-wq/reddit-marketing-mcp/issues)

---

**Made with ❤️ by [wangchenji](https://github.com/1036007003-wq)**
