# Twitter Marketing MCP

MCP (Model Context Protocol) server for Twitter/X marketing automation. Gives your AI assistant (Claude, Cline, etc.) real-time Twitter superpowers.

## ✅ What it does

**Free features (Twitter API v2 free tier or Nitter):**
- 🔍 `search_tweets` — search recent tweets by keyword, hashtag, or user
- 👤 `analyze_account` — analyze any Twitter account: followers, bio, tweet frequency
- 📈 `find_trending` — discover trending topics and hashtags

**Premium features (GitHub Sponsors):**
- 🤖 `generate_tweet` — AI tweet generator (uses DeepSeek API)
- ⏰ `schedule_tweet` — auto-schedule for optimal engagement
- 📊 `track_metrics` — marketing KPI dashboard

## 🚀 Quick Start

```bash
npm install
npm start
```

Add to your MCP client (Claude Desktop / Cline / etc.):

```json
{
  "mcpServers": {
    "twitter-marketing": {
      "command": "node",
      "args": ["/path/to/twitter-marketing-mcp/index.js"],
      "env": {
        "TWITTER_BEARER_TOKEN": "your-token-here"
      }
    }
  }
}
```

## 🔑 Getting a Twitter API v2 Token (free)

1. Go to https://developer.twitter.com/en/portal/dashboard
2. Create a new app (free tier)
3. Generate a **Bearer Token**
4. Add it to your `.env` file:
   ```
   TWITTER_BEARER_TOKEN=AAAAAAAAxxxxxxxxxx
   ```

Free tier limits: 10,000 tweets/month (read-only). Enough for research.

## 🌏 China Users (Twitter is blocked)

Set a proxy in `.env`:

```
HTTP_PROXY=http://127.0.0.1:7890
HTTPS_PROXY=http://127.0.0.1:7890
```

Or use a VPN before running the server.

## 🔑 Premium Features

1. Go to: https://github.com/sponsors/1036007003-wq
2. Pick a tier ($5 / $10 / $25 per month)
3. You'll receive a `LICENSE_KEY`
4. Add it to your `.env` file:
   ```
   LICENSE_KEY=your-license-key
   ```
5. (Optional) Add DeepSeek API key for AI tweet generation:
   ```
   DEEPSEEK_API_KEY=sk-xxx
   ```

## 📖 Example Usage (in Claude / Cline)

```
Search Twitter for "#indiehackers" — what are people talking about?
```

```
Analyze @levelsio's Twitter account — how often does he tweet?
```

```
What's trending on Twitter right now?
```

```
[Premium] Generate a tweet about my SaaS tool — make it viral style.
```

## 🛠️ Tech Stack

- `@modelcontextprotocol/sdk` — MCP protocol
- `node-fetch` — HTTP requests
- Twitter API v2 (free tier for reading)
- Nitter (fallback for users without API key)
- DeepSeek API (optional, for AI tweet generation)

## 🤝 Contributing

PRs welcome! Especially:
- Better Nitter HTML parsing (add `cheerio` dependency)
- More Twitter API endpoints
- Better AI tweet generation prompts
- Support for more LLM providers

## 📄 License

MIT — free to use, modify, and distribute.

## ⭐ Support

If this tool helps you grow on Twitter, please:
- ⭐ Star this repo
- ☕ [Sponsor on GitHub](https://github.com/sponsors/1036007003-wq)
- 🐛 [Report issues](https://github.com/1036007003-wq/twitter-marketing-mcp/issues)

---

**Made with ❤️ by [wangchenji](https://github.com/1036007003-wq)**
